//
//  ViewController.swift
//  calcapp
//
//  Created by Prasadam,Udayasri on 2/11/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

